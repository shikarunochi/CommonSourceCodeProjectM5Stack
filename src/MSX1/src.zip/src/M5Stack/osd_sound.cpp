/*
	Skelton for retropc emulator

	Author : Takeda.Toshiya
	Date   : 2015.11.26-

	M5Stack version.
	modified by shikarunochi 2019.03.21 -

	[ M5Stack sound(dummy) ]
*/

#include "osd.h"
#include "../fileio.h"


void OSD::initialize_sound(int rate, int samples)
{
}

void OSD::release_sound()
{
}

