/*
	Skelton for retropc emulator

	Qt Version : tanam
	Date   : 2013.05.18 -
*/

#ifndef _WINDOWS_H_
#define _WINDOWS_H_

#define _tfopen fopen
#define __assume exit
#define min(a, b) (((a) < (b)) ? (a) : (b))
#define max(a, b) (((a) > (b)) ? (a) : (b))

#endif